function Get-FolderIcon {
    param (
        [Parameter(Mandatory=$true)]
        [string]$FolderPath
    )
    
    # Pfad zur desktop.ini
    $desktopIniPath = Join-Path $FolderPath "desktop.ini"
    
    # Prüfen, ob desktop.ini existiert
    if (Test-Path $desktopIniPath) {
        $desktopIni = Get-Content $desktopIniPath -Raw
        
        # Nach IconResource suchen
        if ($desktopIni -match 'IconResource=([^,]+),(\d+)') {
            $iconPath = $matches[1]
            $iconIndex = $matches[2]
            
            Write-Host "Aktuelles Ordnersymbol:" -ForegroundColor Yellow
            Write-Host "Icon-Pfad: $iconPath" -ForegroundColor Green
            Write-Host "Icon-Index: $iconIndex" -ForegroundColor Green
            
            return @{
                Path = $iconPath
                Index = $iconIndex
            }
        }
    }
    
    Write-Host "Kein benutzerdefiniertes Symbol gefunden oder desktop.ini nicht vorhanden." -ForegroundColor Yellow
    return $null
}


function Get-ItemIcon {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Path
    )

    # .url-Datei
    if ($Path -match '\.url$') {
        if (Test-Path $Path) {
            $content = Get-Content $Path -Raw

            $iconFile  = if ($content -match 'IconFile=(.+)')  { $matches[1].Trim() } else { $null }
            $iconIndex = if ($content -match 'IconIndex=(\d+)') { $matches[1].Trim() } else { $null }

            if ($iconFile) {
                Write-Host "Icon-Pfad:  $iconFile"  -ForegroundColor Green
                Write-Host "Icon-Index: $iconIndex" -ForegroundColor Green
                return @{ Path = $iconFile; Index = $iconIndex }
            }
        }
        Write-Host "Kein Icon in der .url-Datei gefunden." -ForegroundColor Yellow
        return $null
    }

    # Ordner (desktop.ini)
    if (Test-Path $Path -PathType Container) {
        $desktopIniPath = Join-Path $Path "desktop.ini"

        if (Test-Path $desktopIniPath) {
            $content = Get-Content $desktopIniPath -Raw

            if ($content -match 'IconResource=([^,]+),(\d+)') {
                Write-Host "Icon-Pfad:  $($matches[1])" -ForegroundColor Green
                Write-Host "Icon-Index: $($matches[2])" -ForegroundColor Green
                return @{ Path = $matches[1]; Index = $matches[2] }
            }
        }
        Write-Host "Kein benutzerdefiniertes Symbol gefunden." -ForegroundColor Yellow
        return $null
    }

    Write-Host "Nicht unterstützter Typ (kein Ordner, keine .url-Datei)." -ForegroundColor Red
    return $null
}

# Beispielaufrufe
#Get-ItemIcon -Path "C:\Users\Administrator\Desktop\LHT"
Get-ItemIcon -Path "C:\Users\Administrator\Desktop\Google.url"

# Beispielaufruf
Get-FolderIcon -FolderPath "C:\Users\Administrator\Desktop\LHT"